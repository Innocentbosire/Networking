# TCP/UDP Network Scanner

This Python project scans for open TCP and UDP ports on a target IP. Useful for learning network reconnaissance basics.

## 🚀 Usage

```bash
python scanner/tcp_scanner.py
python scanner/udp_scanner.py
```

## 🔧 Features
- Fast TCP connect scans
- Lightweight UDP scans
- Configurable target and port range

## 📜 License
MIT
