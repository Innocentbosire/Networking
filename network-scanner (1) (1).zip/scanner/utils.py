def get_common_ports():
    return [21, 22, 23, 25, 53, 80, 110, 139, 443, 445, 8080]
