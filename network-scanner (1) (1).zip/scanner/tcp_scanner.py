import socket

def tcp_scan(target_ip, ports):
    print(f"Starting TCP scan on {target_ip}")
    for port in ports:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(0.5)
        try:
            sock.connect((target_ip, port))
            print(f"[+] Port {port} is OPEN")
        except:
            pass
        finally:
            sock.close()
