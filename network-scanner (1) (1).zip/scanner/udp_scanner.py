import socket

def udp_scan(target_ip, ports):
    print(f"Starting UDP scan on {target_ip}")
    for port in ports:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(1)
        try:
            sock.sendto(b"Hello", (target_ip, port))
            data, _ = sock.recvfrom(1024)
            print(f"[+] UDP port {port} is OPEN or FILTERED")
        except:
            pass
        finally:
            sock.close()
